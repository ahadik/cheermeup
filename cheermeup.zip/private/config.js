module.exports = {
    twilio_sid : "AC82cbe5c74e577e611160896e7a9f2780",
    twilio_token : "1d1d8c5e031140d3e306c16b684b29a6",
    twilio_number : "+12602364520",
    recipients: [
      // {
      //   name: "Una",
      //   number :  "+14437980015"
      // },
      {
        name : "Alex",
        number : "+12078372578"
      }
    ]
  }